package com.app.model;

public enum Category {
	FASHION, ELECTRONICS;
}
