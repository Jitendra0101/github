package com.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.model.Appointment;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
	
    List<Appointment> findByUserId(String userId);

    void deleteById(Integer id);
    
//    boolean existsById(Integer id);
}