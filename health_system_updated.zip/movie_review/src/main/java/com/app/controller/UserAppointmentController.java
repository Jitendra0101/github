package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.model.Appointment;
import com.app.repository.AppointmentRepository;

@RestController
@RequestMapping("/appointments")
public class UserAppointmentController {

	@Autowired
	private AppointmentRepository appointmentRepository;
	
	@PostMapping
	public ResponseEntity<Appointment> postAppointment(@RequestBody Appointment appointment) {
		Appointment appoint = appointmentRepository.save(appointment);
		return new ResponseEntity<>(appoint, HttpStatus.OK);

	}

	@GetMapping("/upcoming/{userId}")
	public ResponseEntity<List<Appointment>> getUpcomingAppointments(@PathVariable String userId) {
		List<Appointment> userAppointments = appointmentRepository.findByUserId(userId);
		return new ResponseEntity<>(userAppointments, HttpStatus.OK);
	}

	@DeleteMapping("/{apptId}")
	public ResponseEntity<String> cancelAppointment(@PathVariable Integer apptId) {
		if (appointmentRepository.existsById(apptId)) {
			appointmentRepository.deleteById(apptId);
			return new ResponseEntity<>("Appointment cancelled successfully", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("Appointment not found", HttpStatus.NOT_FOUND);
		}
	}
}
