#!/bin/bash

# Prompt the user to enter three numbe
echo "Enter three numbers, separated by spaces:"
read num1 num2 num3

# Find the largest number using a concise conditional approach
largest=$(( num1 > num2 ? (num1 > num3 ? num1 : num3) : (num2 > num3 ? num2 : num3) ))

# Print the largest number
echo "The largest number is: $largest"
