#!/bin/bash

# Accept three numbers from the user
read -p "Enter the first number: " num1
read -p "Enter the second number: " num2
read -p "Enter the third number: " num3

# Calculate the average
sum=$((num1 + num2 + num3))
average=$((sum / 3))

# Display the result
echo "The average of $num1, $num2, and $num3 is: $average"
