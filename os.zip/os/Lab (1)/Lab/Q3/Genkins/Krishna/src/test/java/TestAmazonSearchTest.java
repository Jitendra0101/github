import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;




public class TestAmazonSearchTest {
    private WebDriver driver;

//    @BeforeClass
//    public static void setUp() {
//        // Set the path to your ChromeDriver executable
////        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
//    	WebDriverManager.chromedriver().setup();
//    	
//    	
//        driver = new ChromeDriver();
//    }

    @Test
    public void amazonSearchTest() {
    	
    	WebDriverManager.chromedriver().setup();
    	
    	
        driver = new ChromeDriver();
        // Navigate to amazon.in
        driver.get("https://www.amazon.in");

        // Enter a product
        WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
        searchBox.sendKeys("Laptop");

        // Click on the search button
        WebElement searchButton = driver.findElement(By.id("nav-search-submit-button"));
        searchButton.click();
        
        
        
        
        
        
        WebElement spanElement = driver.findElement(By.xpath("//*[@id=\"search\"]/span[2]/div/h1/div/div[1]/div/div/span[3]"));
        
        System.out.println(spanElement.getText());
        // Verify the title of the result page
//        String pageTitle = driver.getTitle();
        assertEquals(spanElement.getText(), "\"Laptop\"");
//        Assert.assertTrue(, "Title doesn't contain the expected keyword");
    }

//    @AfterClass
//    public static f void tearDown() {
//        // Close the browser
//        if (driver != null) {
//            driver.quit();
//        }
//    }
}
