import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestQ3 {
    private WebDriver driver;

    @Test
    public void practiceLoginScenario() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

        // a. Navigate to https://practice.automationtesting.in/my-account/
        driver.get("https://practice.automationtesting.in/my-account/");

        // b. Enter first name, last name, and click on Login
        WebElement firstName = driver.findElement(By.id("username"));
        firstName.sendKeys("Johnsena");

        WebElement lastName = driver.findElement(By.id("password"));
        lastName.sendKeys("Pranav@12345");
        WebElement loginButton = driver.findElement(By.name("login"));
        loginButton.click();

     // c. Verify the error message
        WebElement errorMessage = driver.findElement(By.xpath("//*[@id='page-36']/div/div[1]/ul/li"));
        assertEquals(errorMessage.getText(), "Error: The password you entered for the username Johnsena is incorrect. Lost your password?");


        // Close the browser
        if (driver != null) {
            driver.quit();////*[@id="page-36"]/div/div[1]/ul
        }
    }
}
