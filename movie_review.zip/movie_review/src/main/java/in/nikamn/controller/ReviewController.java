package in.nikamn.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nikamn.dto.ReviewDto;
import in.nikamn.model.Review;
import in.nikamn.model.User;
import in.nikamn.service.ReviewService;
import in.nikamn.service.UserService;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;
    private final UserService userService;

    @GetMapping
    public List<Review> getAllReviews() {
        return reviewService.getAllReviews();
    }

    @GetMapping("/{id}")
    public Review getReviewById(@PathVariable Integer id) {
        return reviewService.getReviewById(id);
    }

    @PostMapping
    public Review postReview(@RequestBody ReviewDto reviewDto) {
        int userId = reviewDto.getUserId();
        User user = userService.getUserById(userId).get();
        Review review = Review.builder()
                .review(reviewDto.getReview())
                .rating(reviewDto.getRating())
                .modified(reviewDto.getModified())
                .title(reviewDto.getTitle())
                .releaseDate(reviewDto.getReleaseDate())
                .user(user)
                .build();
        return reviewService.postReview(review);
    }

    @PutMapping("/{id}")
    public Review putReview(@PathVariable Integer id, @RequestBody Review review) {
        return reviewService.putReview(id, review);
    }

    @DeleteMapping("/{id}")
    public void deleteReview(@PathVariable Integer id) {
        reviewService.deleteReview(id);
    }
}
