package in.nikamn.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import in.nikamn.model.Movie;
import in.nikamn.repository.MovieRepository;
import in.nikamn.utils.Utils;
import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class MovieService {
    private final MovieRepository movieRepository;

    public Optional<Movie> getMovieById(Integer id) {
        return movieRepository.findById(id);
    }

    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    public Movie postMovie(Movie movie) {
        return movieRepository.save(movie);
    }

    public Movie putMovie(Integer id, Movie movie) {
        Optional<Movie> persistentMovie = movieRepository.findById(id);

        if (persistentMovie.isPresent()) {
            Utils.copyNonNullProperties(movie, persistentMovie.get());
        }

        return movieRepository.save(persistentMovie.get());
    }

    public void deleteMovie(Integer id) {
        movieRepository.deleteById(id);
    }
}
