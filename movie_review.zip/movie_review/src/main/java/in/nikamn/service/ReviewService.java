package in.nikamn.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import in.nikamn.model.Review;
import in.nikamn.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class ReviewService {
    private final ReviewRepository reviewRepository;

    public Review getReviewById(Integer id) {
        Review review = reviewRepository.findById(id).get();
        return review;
    }

    public List<Review> getAllReviews() {
        List<Review> allReviews = reviewRepository.findAll();
        System.out.println(allReviews.toString());
        allReviews.size();
        return allReviews;
    }

    public Review postReview(Review review) {
        return reviewRepository.save(review);
    }

    public Review putReview(Integer id, Review review) {
        review.setId(id);
        return reviewRepository.save(review);
    }

    public void deleteReview(Integer id) {
        reviewRepository.deleteById(id);
    }
}
