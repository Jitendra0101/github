package in.nikamn.dto;

import java.time.LocalDate;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReviewDto {
    private String review;
    private int rating;
    private Date modified;
    private String title;
    private LocalDate releaseDate;
    private Integer userId;
}
