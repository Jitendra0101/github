package in.nikamn.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nikamn.model.Movie;

public interface MovieRepository extends JpaRepository<Movie, Integer> {
}
