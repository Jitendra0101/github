package in.nikamn.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import in.nikamn.model.Review;

public interface ReviewRepository extends JpaRepository<Review, Integer> {
}
